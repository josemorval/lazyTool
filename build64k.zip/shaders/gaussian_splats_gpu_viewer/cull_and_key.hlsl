#include "gs_common.hlsl"

// Pass 2: camera culling and compact writing of visible splats.
//
// The output list is compact: SortPairs[0..visibleCount-1]. The allocation
// counter is explicit: it is the InstanceCount DWORD in the indirect draw
// argument buffer. It is just a normal integer updated with InterlockedAdd, so
// the state stays visible in the graph.

StructuredBuffer<GaussianSplat> Splats : register(t0);
RWStructuredBuffer<uint> IndirectArgs : register(u0);
RWStructuredBuffer<SortPair> SortPairs : register(u1);

bool splat_survives_camera(float3 world_pos, float radius, float opacity)
{
    if (opacity <= max(SplatTuning.z, 0.0))
        return false;

    float4 clip = mul(ViewProj, float4(world_pos, 1.0));
    if (clip.w <= 1e-5)
        return false;

    float3 ndc = clip.xyz / clip.w;
    float pad = max(CullingTuning.x, 0.0);

    // A small depth-aware padding term prevents large nearby splats from
    // popping when only their center is just outside the frustum.
    float view_depth = max(dot(world_pos - CamPos.xyz, normalize(CamDir.xyz)), 1e-4);
    float radius_pad = saturate(radius / view_depth) * max(SplatTuning.y, 1.0);
    pad += radius_pad;

    if (ndc.x < -1.0 - pad || ndc.x > 1.0 + pad)
        return false;
    if (ndc.y < -1.0 - pad || ndc.y > 1.0 + pad)
        return false;
    if (ndc.z < -pad || ndc.z > 1.0 + pad)
        return false;

    return true;
}

[numthreads(GS_THREADS, 1, 1)]
void CSMain(uint3 id : SV_DispatchThreadID)
{
    uint splat_count = 0u;
    uint stride = 0u;
    Splats.GetDimensions(splat_count, stride);
    if (id.x >= splat_count)
        return;

    GaussianSplat s = Splats[id.x];
    float3 world_pos = gs_world_pos(s);
    float3 world_scale = gs_world_scale(s);
    float radius = max(world_scale.x, max(world_scale.y, world_scale.z));
    float opacity = gs_opacity(s);

    if (!splat_survives_camera(world_pos, radius, opacity))
        return;

    uint pair_capacity = 0u;
    uint pair_stride = 0u;
    SortPairs.GetDimensions(pair_capacity, pair_stride);
    uint write_capacity = min(gs_clamp_capacity(MaxVisible), gs_clamp_capacity(SortCapacity));
    write_capacity = min(write_capacity, pair_capacity);
    write_capacity = min(write_capacity, (uint)GS_MAX_SORT_CAPACITY);

    uint slot = 0u;
    InterlockedAdd(IndirectArgs[GS_DRAW_INSTANCE_COUNT], 1u, slot);

    // Overflow is accounted for later in finalize_sort_args.hlsl. The counter
    // is allowed to exceed the writable list so the debug/stat value remains
    // meaningful, but writes are clamped to the actual pair buffer capacity.
    if (slot >= write_capacity)
        return;

    SortPair p;
    p.key = gs_depth_key(world_pos);
    p.index = id.x;
    SortPairs[slot] = p;
}

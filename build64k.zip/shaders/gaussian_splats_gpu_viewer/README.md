# Gaussian Splats GPU Viewer

This folder is a standalone lazyTool example shader set for full-GPU Gaussian splat rendering.

Pipeline:

1. `reset_args.hlsl` clears frame counters and indirect arguments.
2. `cull_and_key.hlsl` culls splats against the camera and compact-writes visible `(depthKey, splatIndex)` pairs using an explicit `InterlockedAdd` counter.
3. `finalize_sort_args.hlsl` clamps the visible count, writes draw and dispatch indirect arguments, and resets the radix state.
4. `radix_histogram.hlsl`, `radix_scan_bins.hlsl`, `radix_prefix_bins.hlsl`, `radix_scatter.hlsl`, and `radix_advance.hlsl` run inside a lazyTool `repeat` block.
5. `draw_splats.hlsl` draws procedural Gaussian quads with `DrawInstancedIndirect`.

The included project uses `assets/models/sofa.ply`, 524288-entry ping-pong sort buffers, and a `repeat 4` block. Each iteration runs two 4-bit radix passes, so all 32 depth-key bits are sorted in 8 passes.

Transform controls live in `UserCB`:

- `SceneOffsetScale.xyz`: translation.
- `SceneOffsetScale.w`: uniform scale.
- `SceneAxisScale.xyz`: per-axis scale; use a negative component to flip an upside-down PLY.
- `SplatTuning.x/y`: visible splat footprint. Lower these if the image looks too dreamy or smeared.
- `SplatTuning.z`: alpha discard threshold. Raise it slightly to remove faint halos.
- `SplatTuning.w`: opacity multiplier.
- `CullingTuning.z`: maximum one-sigma world radius used by culling and drawing. Lower it for PLYs with very elongated Gaussians.

To load another PLY in the project:

1. Select the `gs_sofa` GaussianSplat resource.
2. Change `Path` to another `.ply` and press `Reload PLY`.
3. Select `SceneOffsetScale`, `SceneAxisScale`, `SplatTuning`, and `CullingTuning` in the User CB panel to fit and sharpen the asset.
4. If the file contains more than 524288 splats, decide whether capping is acceptable. The default cap is cheap and safe. To render more, increase `MaxVisible`, `SortCapacity`, both `gs_sort_pairs_*` counts, `GS_MAX_SORT_GROUPS`, and both `gs_radix_group_counts` / `gs_radix_group_offsets` counts. The group-buffer count should be `16 * (SortCapacity / 128)`.

The loader accepts ASCII and `binary_little_endian` 3DGS-style PLYs. It requires `x`, `y`, and `z`; it uses `scale_0..2`, `rot_0..3`, `opacity`, and `f_dc_0..2` when present. `f_rest_*` properties are counted for diagnostics but this viewer renders the DC color only.

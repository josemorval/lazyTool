// Shared declarations for the new full-GPU Gaussian splat viewer.
//
// The project intentionally keeps this file explicit and educational:
// - t0 is the immutable GaussianSplat resource loaded from a .ply file.
// - u*/t* scratch buffers are owned by the compute pipeline.
// - b0 is the engine SceneCB.
// - b2 is UserCB, so every value below can be exposed by lazyTool.
//
// CPU work in this example stops at loading the PLY once. Every frame after
// that is GPU cull -> indirect args -> GPU radix sort -> indirect draw.

#ifndef GS_COMMON_HLSL
#define GS_COMMON_HLSL

cbuffer SceneCB : register(b0)
{
    float4x4 ViewProj;
    float4 TimeVec;
    float4 LightDir;
    float4 LightColor;
    float4 CamPos;
    float4x4 ShadowViewProj;
    float4x4 InvViewProj;
    float4x4 PrevViewProj;
    float4x4 PrevInvViewProj;
    float4x4 PrevShadowViewProj;
    float4 CamDir;
    float4 ShadowCascadeSplits;
    float4 ShadowParams;          // y = camera near, z = camera far in lazyTool.
    float4 ShadowCascadeRects[4];
    float4x4 ShadowCascadeViewProj[4];
};

cbuffer UserCB : register(b2)
{
    // Hard capacity of the sort/draw list. Keep this <= the element count of
    // gs_sort_pairs in the project. The included project uses 524288.
    int MaxVisible;

    // Power-of-two sort capacity. The included shader scan supports up to
    // 524288 entries: 4096 thread groups * 128 splats per group.
    int SortCapacity;

    // xyz translates the PLY in world space, w scales it uniformly. This is
    // the cheap "scene transform" knob for trying different PLYs without
    // editing them.
    float4 SceneOffsetScale;

    // xyz scales individual PLY axes before the uniform scale above.
    // Negative values flip an axis. The example uses y=-1 because this PLY
    // appears upside down in this viewer's camera convention.
    // w is reserved.
    float4 SceneAxisScale;

    // x = splat radius multiplier.
    // y = sigma radius drawn by the quad. 3 means the quad edge is 3 sigma.
    // z = alpha cutoff used both by culling and PS discard.
    // w = opacity multiplier, useful because different PLYs are calibrated
    //     differently.
    float4 SplatTuning;

    // x = NDC frustum padding. Splats are not points, so culling exactly at
    //     [-1,1] would pop large edge splats.
    // y = minimum world-space radius after scale.
    // z = maximum world-space one-sigma radius after scale. The culler and
    //     drawer both use it as a safety clamp, because some PLYs contain a
    //     few extremely elongated Gaussians that can smear the whole frame.
    // w = reserved.
    float4 CullingTuning;

    // xyz = color tint, w = exposure-like brightness multiplier.
    float4 ToneTuning;
};

struct GaussianSplat
{
    float4 pos_opacity; // xyz = center, w = opacity after CPU sigmoid decode.
    float4 quat;        // xyzw quaternion.
    float4 scale;       // xyz = Gaussian stddev-like scale.
    float4 color;       // rgb = decoded DC color, a = opacity duplicate.
};

struct SortPair
{
    uint key;   // Sort ascending. Smaller key is farther from camera.
    uint index; // Index into the GaussianSplat buffer.
};

// Layout of gs_indirect_args. In the project it is still a StructuredBuffer
// resource, just flagged as Indirect Args so DX11 accepts it in
// DrawInstancedIndirect and DispatchIndirect.
#define GS_DRAW_VERTEX_COUNT    0u
#define GS_DRAW_INSTANCE_COUNT  1u
#define GS_DRAW_START_VERTEX    2u
#define GS_DRAW_START_INSTANCE  3u

// DispatchIndirect reads three DWORDs. Offset 16 bytes means element 4.
#define GS_DISPATCH_X           4u
#define GS_DISPATCH_Y           5u
#define GS_DISPATCH_Z           6u

// Layout of gs_sort_state. It is a normal RWStructuredBuffer<uint>.
#define GS_STATE_VISIBLE_COUNT  0u
#define GS_STATE_SORT_COUNT     1u
#define GS_STATE_RADIX_SHIFT    2u
#define GS_STATE_SORT_GROUPS    3u
#define GS_STATE_DONE           4u
#define GS_STATE_RAW_VISIBLE    5u
#define GS_STATE_OVERFLOW       6u

#define GS_THREADS              128u
#define GS_RADIX_BITS           4u
#define GS_RADIX_BINS           16u
#define GS_MAX_SORT_GROUPS      4096u
#define GS_MAX_SORT_CAPACITY    (GS_MAX_SORT_GROUPS * GS_THREADS)
#define GS_INVALID_KEY          0xffffffffu
#define GS_INVALID_INDEX        0xffffffffu

uint gs_clamp_capacity(int value)
{
    return (uint)max(value, 1);
}

uint gs_next_pow2(uint v)
{
    v = max(v, 1u);
    v--;
    v |= v >> 1;
    v |= v >> 2;
    v |= v >> 4;
    v |= v >> 8;
    v |= v >> 16;
    return v + 1u;
}

SortPair gs_invalid_pair()
{
    SortPair p;
    p.key = GS_INVALID_KEY;
    p.index = GS_INVALID_INDEX;
    return p;
}

float3 gs_world_pos(GaussianSplat s)
{
    return (s.pos_opacity.xyz * SceneAxisScale.xyz) * SceneOffsetScale.w + SceneOffsetScale.xyz;
}

float3 gs_world_scale(GaussianSplat s)
{
    float scene_scale = max(abs(SceneOffsetScale.w), 1e-5);
    float radius_scale = max(SplatTuning.x, 1e-5);
    float axis_scale = max(abs(SceneAxisScale.x), max(abs(SceneAxisScale.y), abs(SceneAxisScale.z)));
    axis_scale = max(axis_scale, 1e-5);
    float3 sc = abs(s.scale.xyz) * scene_scale * axis_scale * radius_scale;
    sc = max(sc, CullingTuning.yyy);
    if (CullingTuning.z > 0.0)
        sc = min(sc, CullingTuning.zzz);
    return sc;
}

float3 gs_transform_vector(float3 v)
{
    return (v * SceneAxisScale.xyz) * SceneOffsetScale.w;
}

float3 gs_clamp_world_axis(float3 v)
{
    if (CullingTuning.z <= 0.0)
        return v;

    float len = length(v);
    if (len <= CullingTuning.z || len <= 1e-8)
        return v;

    return v * (CullingTuning.z / len);
}

float gs_opacity(GaussianSplat s)
{
    return saturate(s.pos_opacity.w * max(SplatTuning.w, 0.0));
}

uint gs_depth_key(float3 world_pos)
{
    float near_z = max(ShadowParams.y, 1e-5);
    float far_z = max(ShadowParams.z, near_z + 1e-4);
    float view_depth = dot(world_pos - CamPos.xyz, normalize(CamDir.xyz));
    float depth01 = saturate((view_depth - near_z) / (far_z - near_z));

    // For alpha blending we want back-to-front rendering. Bitonic below sorts
    // ascending, so far splats get small keys and near splats get large keys.
    uint q = (uint)min(depth01 * 4294967295.0, 4294967294.0);
    return 0xfffffffeu - q;
}

bool gs_pair_greater(SortPair a, SortPair b)
{
    return (a.key > b.key) || (a.key == b.key && a.index > b.index);
}

bool gs_pair_less(SortPair a, SortPair b)
{
    return (a.key < b.key) || (a.key == b.key && a.index < b.index);
}

uint gs_radix_bin(uint key, uint shift)
{
    return (key >> shift) & (GS_RADIX_BINS - 1u);
}

float3 gs_quat_rotate(float4 q, float3 v)
{
    // q is normalized on import, but normalizing here makes this shader robust
    // against hand-authored or future generated splat buffers.
    q = normalize(q);
    return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v);
}

#endif

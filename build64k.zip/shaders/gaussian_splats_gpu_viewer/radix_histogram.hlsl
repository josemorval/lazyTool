#include "gs_common.hlsl"

// Radix pass A: build per-thread-group histograms.
//
// Each group handles 128 SortPair entries and writes 16 counters:
//
//   RadixGroupCounts[group * 16 + bin]
//
// This is the first half of a 4-bit radix pass. It does not reorder anything;
// it only answers "how many keys in this group have this 4-bit digit?".

StructuredBuffer<SortPair> InputPairs : register(t0);
StructuredBuffer<uint> SortState : register(t1);
RWStructuredBuffer<uint> RadixGroupCounts : register(u0);

groupshared uint SharedBins[GS_RADIX_BINS];

[numthreads(GS_THREADS, 1, 1)]
void CSMain(uint3 group_id : SV_GroupID, uint lane : SV_GroupIndex, uint3 dispatch_id : SV_DispatchThreadID)
{
    if (lane < GS_RADIX_BINS)
        SharedBins[lane] = 0u;
    GroupMemoryBarrierWithGroupSync();

    uint sort_count = SortState[GS_STATE_SORT_COUNT];
    uint sort_groups = SortState[GS_STATE_SORT_GROUPS];
    uint shift = SortState[GS_STATE_RADIX_SHIFT];

    if (SortState[GS_STATE_DONE] == 0u && group_id.x < sort_groups && dispatch_id.x < sort_count)
    {
        uint bin = gs_radix_bin(InputPairs[dispatch_id.x].key, shift);
        InterlockedAdd(SharedBins[bin], 1u);
    }

    GroupMemoryBarrierWithGroupSync();

    if (lane < GS_RADIX_BINS && group_id.x < GS_MAX_SORT_GROUPS)
        RadixGroupCounts[group_id.x * GS_RADIX_BINS + lane] = SharedBins[lane];
}

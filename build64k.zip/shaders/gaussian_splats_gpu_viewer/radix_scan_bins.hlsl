#include "gs_common.hlsl"

// Radix pass B: exclusive scan of group histograms.
//
// Dispatch as 1 x 16 x 1 groups. group_id.y selects the radix bin.
// One workgroup scans all group counts for that bin, up to 4096 groups.
//
// Outputs:
// - RadixGroupOffsets[group * 16 + bin] = number of prior elements in the same
//   bin from earlier thread groups.
// - RadixBinStarts[bin] is temporarily the total count for that bin; the next
//   tiny pass converts those totals into exclusive global bin starts.

StructuredBuffer<uint> RadixGroupCounts : register(t0);
StructuredBuffer<uint> SortState : register(t1);
RWStructuredBuffer<uint> RadixGroupOffsets : register(u0);
RWStructuredBuffer<uint> RadixBinStarts : register(u1);

groupshared uint Scan[GS_MAX_SORT_GROUPS];

[numthreads(1024, 1, 1)]
void CSMain(uint3 group_id : SV_GroupID, uint lane : SV_GroupIndex)
{
    uint bin = group_id.y;
    uint sort_groups = min(SortState[GS_STATE_SORT_GROUPS], (uint)GS_MAX_SORT_GROUPS);

    for (uint i = lane; i < GS_MAX_SORT_GROUPS; i += 1024u)
    {
        Scan[i] = i < sort_groups ? RadixGroupCounts[i * GS_RADIX_BINS + bin] : 0u;
    }
    GroupMemoryBarrierWithGroupSync();

    // Blelloch upsweep.
    [loop]
    for (uint offset = 1u; offset < GS_MAX_SORT_GROUPS; offset <<= 1u)
    {
        uint step = offset << 1u;
        for (uint idx = (lane + 1u) * step - 1u; idx < GS_MAX_SORT_GROUPS; idx += 1024u * step)
            Scan[idx] += Scan[idx - offset];
        GroupMemoryBarrierWithGroupSync();
    }

    if (lane == 0u)
    {
        RadixBinStarts[bin] = Scan[GS_MAX_SORT_GROUPS - 1u];
        Scan[GS_MAX_SORT_GROUPS - 1u] = 0u;
    }
    GroupMemoryBarrierWithGroupSync();

    // Blelloch downsweep. After this, Scan[i] is the exclusive prefix for i.
    [loop]
    for (uint offset = GS_MAX_SORT_GROUPS >> 1u; offset >= 1u; offset >>= 1u)
    {
        uint step = offset << 1u;
        for (uint idx = (lane + 1u) * step - 1u; idx < GS_MAX_SORT_GROUPS; idx += 1024u * step)
        {
            uint t = Scan[idx - offset];
            Scan[idx - offset] = Scan[idx];
            Scan[idx] += t;
        }
        GroupMemoryBarrierWithGroupSync();
        if (offset == 1u)
            break;
    }

    for (uint i = lane; i < sort_groups; i += 1024u)
        RadixGroupOffsets[i * GS_RADIX_BINS + bin] = Scan[i];
}

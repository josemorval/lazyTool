#include "gs_common.hlsl"

// Pass 3: convert the culling counter into indirect draw and sort metadata.
//
// This pass is small but important:
// - clamps the visible count to the allocated list capacity,
// - writes DispatchIndirect args for the radix histogram/scatter passes,
// - initializes the radix state machine.

RWStructuredBuffer<uint> IndirectArgs : register(u0);
RWStructuredBuffer<uint> SortState : register(u1);
RWStructuredBuffer<SortPair> SortPairs : register(u2);

[numthreads(1, 1, 1)]
void CSMain(uint3 id : SV_DispatchThreadID)
{
    if (id.x != 0 || id.y != 0 || id.z != 0)
        return;

    uint capacity = gs_clamp_capacity(MaxVisible);
    uint sort_capacity = gs_clamp_capacity(SortCapacity);
    uint pair_capacity = 0u;
    uint pair_stride = 0u;
    SortPairs.GetDimensions(pair_capacity, pair_stride);
    capacity = min(capacity, pair_capacity);
    capacity = min(capacity, (uint)GS_MAX_SORT_CAPACITY);
    sort_capacity = min(sort_capacity, capacity);

    uint raw_visible = IndirectArgs[GS_DRAW_INSTANCE_COUNT];
    uint visible = min(raw_visible, sort_capacity);
    uint sort_count = visible;
    uint sort_groups = max((sort_count + GS_THREADS - 1u) / GS_THREADS, 1u);

    // DrawInstancedIndirect reads these four DWORDs at byte offset 0.
    IndirectArgs[GS_DRAW_VERTEX_COUNT] = 6u;
    IndirectArgs[GS_DRAW_INSTANCE_COUNT] = visible;
    IndirectArgs[GS_DRAW_START_VERTEX] = 0u;
    IndirectArgs[GS_DRAW_START_INSTANCE] = 0u;

    // DispatchIndirect reads these three DWORDs at byte offset 16.
    IndirectArgs[GS_DISPATCH_X] = sort_groups;
    IndirectArgs[GS_DISPATCH_Y] = 1u;
    IndirectArgs[GS_DISPATCH_Z] = 1u;

    SortState[GS_STATE_VISIBLE_COUNT] = visible;
    SortState[GS_STATE_SORT_COUNT] = sort_count;
    SortState[GS_STATE_RADIX_SHIFT] = 0u;
    SortState[GS_STATE_SORT_GROUPS] = sort_groups;
    SortState[GS_STATE_DONE] = (sort_count <= 1u) ? 1u : 0u;
    SortState[GS_STATE_RAW_VISIBLE] = raw_visible;
    SortState[GS_STATE_OVERFLOW] = raw_visible > visible ? raw_visible - visible : 0u;
}

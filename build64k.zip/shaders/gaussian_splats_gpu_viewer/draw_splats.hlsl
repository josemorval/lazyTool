#include "gs_common.hlsl"

// Final pass: procedural indirect draw.
//
// DrawInstancedIndirect supplies one instance per visible splat. The VS expands
// each instance into a camera-facing quad and the PS evaluates a Gaussian alpha
// falloff. The sorted pair list is already back-to-front, so normal alpha
// blending can composite the splats without any CPU intervention.

StructuredBuffer<GaussianSplat> Splats : register(t0);
StructuredBuffer<SortPair> SortPairs : register(t1);

struct VSOut
{
    float4 pos : SV_POSITION;
    float2 sigma_uv : TEXCOORD0;
    float4 color_opacity : TEXCOORD1;
};

float2 quad_corner(uint vertex_id)
{
    // Two triangles: (-1,-1) (1,-1) (1,1), (-1,-1) (1,1) (-1,1).
    static const float2 kCorners[6] =
    {
        float2(-1.0, -1.0),
        float2( 1.0, -1.0),
        float2( 1.0,  1.0),
        float2(-1.0, -1.0),
        float2( 1.0,  1.0),
        float2(-1.0,  1.0)
    };
    return kCorners[vertex_id % 6u];
}

void covariance_axes(GaussianSplat s, out float3 axis0, out float3 axis1)
{
    float3 sc = abs(s.scale.xyz) * max(SplatTuning.x, 1e-5);

    // Rotate the three Gaussian basis vectors into world space, then project
    // their covariance into the camera right/up plane. This gives an ellipse
    // that reacts to the PLY's anisotropic scale and quaternion instead of a
    // plain fixed-size sprite.
    float3 bx = gs_clamp_world_axis(gs_transform_vector(gs_quat_rotate(s.quat, float3(1.0, 0.0, 0.0)) * sc.x));
    float3 by = gs_clamp_world_axis(gs_transform_vector(gs_quat_rotate(s.quat, float3(0.0, 1.0, 0.0)) * sc.y));
    float3 bz = gs_clamp_world_axis(gs_transform_vector(gs_quat_rotate(s.quat, float3(0.0, 0.0, 1.0)) * sc.z));

    float3 cam_r = normalize(cross(float3(0.0, 1.0, 0.0), normalize(CamDir.xyz)));
    if (dot(cam_r, cam_r) < 1e-4)
        cam_r = float3(1.0, 0.0, 0.0);
    float3 cam_u = normalize(cross(normalize(CamDir.xyz), cam_r));

    float2 px = float2(dot(bx, cam_r), dot(bx, cam_u));
    float2 py = float2(dot(by, cam_r), dot(by, cam_u));
    float2 pz = float2(dot(bz, cam_r), dot(bz, cam_u));

    float c00 = dot(float3(px.x, py.x, pz.x), float3(px.x, py.x, pz.x));
    float c01 = dot(float3(px.x, py.x, pz.x), float3(px.y, py.y, pz.y));
    float c11 = dot(float3(px.y, py.y, pz.y), float3(px.y, py.y, pz.y));

    float trace_half = 0.5 * (c00 + c11);
    float delta = sqrt(max((0.5 * (c00 - c11)) * (0.5 * (c00 - c11)) + c01 * c01, 0.0));
    float lambda0 = max(trace_half + delta, 1e-8);
    float lambda1 = max(trace_half - delta, 1e-8);

    float2 e0 = abs(c01) > 1e-7 ? normalize(float2(c01, lambda0 - c00)) : float2(1.0, 0.0);
    float2 e1 = float2(-e0.y, e0.x);

    float sigma_radius = max(SplatTuning.y, 0.5);
    axis0 = (cam_r * e0.x + cam_u * e0.y) * sqrt(lambda0) * sigma_radius;
    axis1 = (cam_r * e1.x + cam_u * e1.y) * sqrt(lambda1) * sigma_radius;
}

VSOut VSMain(uint vertex_id : SV_VertexID, uint instance_id : SV_InstanceID)
{
    SortPair pair = SortPairs[instance_id];
    GaussianSplat s = Splats[pair.index];

    float3 center = gs_world_pos(s);
    float3 axis0;
    float3 axis1;
    covariance_axes(s, axis0, axis1);

    float2 corner = quad_corner(vertex_id);
    float3 world_pos = center + axis0 * corner.x + axis1 * corner.y;

    VSOut o;
    o.pos = mul(ViewProj, float4(world_pos, 1.0));
    o.sigma_uv = corner * max(SplatTuning.y, 0.5);
    o.color_opacity = float4(s.color.rgb * ToneTuning.rgb * max(ToneTuning.w, 0.0), gs_opacity(s));
    return o;
}

float4 PSMain(VSOut i) : SV_Target
{
    float r2 = dot(i.sigma_uv, i.sigma_uv);
    float alpha = i.color_opacity.a * exp(-0.5 * r2);
    if (alpha <= max(SplatTuning.z, 0.0))
        discard;

    return float4(saturate(i.color_opacity.rgb), saturate(alpha));
}

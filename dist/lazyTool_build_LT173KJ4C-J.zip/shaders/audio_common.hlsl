#ifndef LAZYTOOL_AUDIO_COMMON_HLSL
#define LAZYTOOL_AUDIO_COMMON_HLSL

// Audio compute ABI used by lazyTool's GPU audio player.
//
// Output format:
//   AudioOut[i] = stereo PCM16 packed as low 16 bits = left, high 16 bits = right.
//
// Runtime bindings:
//   SceneCB = b0, UserCB = b2, AudioCB = b3, AudioOut = u0.

cbuffer AudioCB : register(b3)
{
    uint  AudioSampleStart;
    uint  AudioSampleCount;
    uint  AudioSampleRate;
    uint  AudioChannels;
    float AudioTimeSeconds;
    float AudioDurationSeconds;
    float AudioMasterVolume;
    float AudioPad0;
};

RWStructuredBuffer<uint> AudioOut : register(u0);

static const float LT_AUDIO_PI = 3.14159265359;
static const float LT_AUDIO_TAU = 6.28318530718;

float lt_audio_sample_time(uint local_sample)
{
    return (float)(AudioSampleStart + local_sample) / (float)max(AudioSampleRate, 1u);
}

int lt_audio_to_i16(float v)
{
    return (int)round(clamp(v, -1.0, 1.0) * 32767.0);
}

uint lt_audio_pack_i16(float left, float right)
{
    int l = lt_audio_to_i16(left * AudioMasterVolume);
    int r = lt_audio_to_i16(right * AudioMasterVolume);
    return (uint)(l & 0xffff) | ((uint)(r & 0xffff) << 16);
}

void lt_audio_store(uint local_sample, float left, float right)
{
    if (local_sample < AudioSampleCount)
        AudioOut[local_sample] = lt_audio_pack_i16(left, right);
}

#endif
